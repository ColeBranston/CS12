# Name: Cole Branston
# Date: 2022/12/14
# Purpose: program that uses recursion to solve a maze from different S positions and tells the user the number of steps needed to move from each position to the exit.

def ReadDoc(): #initializing the function
    inFile = open("TestMaze.txt", 'r') #opening and reading into the text file
    line = inFile.readline().rstrip("\n") #reading the first line and stripping the line of its "\n"
    row = 0 #intializing the row to 0

    while line != "": #looping through as long at there are things in the line
        txt.append([line[0]]) #adding the first character in a list to the (now) array
        for x in range(1, len(line)): #itterating by 1 to the 
            txt[row].append(line[x])

        row += 1 #increasing the row counter by 1 each time
        line = inFile.readline().rstrip("\n") #reading the next line and stripping it of its "\n"

    inFile.close() #closing the text file

def printDoc(): #intializing the function
    for x in range(len(txt)): #itterating through the txt file based on its length
        for y in range(len(txt[x])): #itterating basd on the length of each list in the array
            print(txt[x][y], end = " ") #printing each part of the file with a space inbetween each character to make it look nice
 
        print() #making a space

def check(x, y): #initializing the functiion using the indexs for the S as parameters
    global counter, successful #globaling the counter and successful variable

    if txt[x][y] == "X": #checking if the txt element is an X
        successful = True #setting the successful varriable to True

    else: #checking that the element is something other than an X
        txt[x][y] = "-" #setting the current element to the visisted variable of "-"

        if txt[x-1][y] in [".", "X"]: #checking that the above element in the maze is either  a . or an X
            check(x-1, y) #calling the function looking above the current element

        if not successful: #checking that the successful variable isn't true
            if txt[x+1][y] in [".", "X"]: #checking that the above element in the maze is either  a . or an X
                check(x+1, y) #calling the function looking below the current element

        if not successful:#checking that the successful variable isn't true
            if txt[x][y-1] in [".", "X"]: #checking that the above element in the maze is either  a . or an X
                check(x, y-1) #calling the function looking to the left of the element

        if not successful:#checking that the successful variable isn't true
            if txt[x][y+1] in [".", "X"]: #checking that the above element in the maze is either  a . or an X
                check(x, y+1) #calling hte function looking to the right of the element

    if successful: #checking if the successful variable is True
        counter += 1 #increasing the counter by 1 each time representing the length of the path

txt = [] #intiailizing the txt list as []
            
ReadDoc() #calling the ReadDoc function
printDoc() #calling the printDoc function
print() #making a space

for x in range(len(txt)): #itterating through the array by its length
    for y in range(len(txt[x])): #itterting through each list by its length 

        if txt[x][y] == "S": #checking if the maze element is an S

            counter = 0 #setting the counter to 0
            successful = False #setting the successful variable to False

            txt = [] #resetting the list
            ReadDoc() #calling the ReadDoc function to reread in the maze

            check(x, y) #calling the check function with the index of the S as paremeters

            print("From starting position", [x,y], "it took", counter, "Steps.") #telling the user starting position in the maze and the amount of steps needed to exit.