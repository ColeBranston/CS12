# Name: Cole Branston
# Date: 2022/12/14
# Purpose: Create a program that uses recursion to find the term in the math sequence

def mathSequence(num): #creating the recursive function
    if num == 1: #checking for the base case
        return 4 #returning the base case of 4
    
    else: #checking that the base case has not been met
        return 5*mathSequence(num-1)+3 #returning the called function within the math sequence

num = int(input("What term of the sequence would you like to see?: ")) #asking the user for the term of the sequence they want to see

while num < 1: #checking that their is valid input
    num = int(input("What term of the sequence would you like to see?: ")) #asking the user for the term of the sequence they want to see

val = mathSequence(num) #calling the nth term from the recusive function

print("The", str(num)+"th term is:", val) #telling the user there term and the nth term.