import java.util.Scanner; //importing the scanner library
import java.util.Arrays; //importing the arrays library

public class Prime_Number_Calculator { //inializing the class

    static int [] pCalc(int num, int [] factors){ //initalizing my method
        for (int x = 1; x < num+1; x += 1){ //for loop intterating from the range of 1 to the num (I could have done from 2 to Math.round(num/2), but I wanted it to always include 1 and the num)
            if (num % x == 0){ //checking if the number is a factor
                factors = Arrays.copyOf(factors, factors.length + 1); //increasing the length of the array by 1 each time
                factors[factors.length - 1] = x; //adding the number to the list
            }
        }
        return factors; //returning the factors list
    }
    public static void main(String[] args){ //initalizing the main method

        String again = "Y"; //intiailizing the again variable to Y for later restart

        while (again == "Y"){ //while loop used to run code and restart the code based on if again is equal to Y

            try{ //try statement not allowing for a user to error out

                Scanner scan = new Scanner(System.in); //initalzing the scanner variable

                System.out.print("What is your num?: "); //asking the user for their number
                int num = scan.nextInt(); 

                int [] factors = new int[0]; //initializing the factors array

                factors = pCalc(num, factors); //calling the list from the function

                if (factors.length > 2){ //checking if the length of the array is greater than 2
                    System.out.println("\nThis is a composite number"+"\nThe factors for this number are: "+Arrays.toString(factors)); //telling the user that their number is composite and listing its factors

                }

                else { //checking if the length is equal to 2 
                    System.out.println("\nThis is a prime number"+"\nThe factors for this number are: "+Arrays.toString(factors)); //telling the user that their number is prime and listing 1 and itself as factors

                }

                System.out.print("Do you want to restart the program? (Y/N): "); //asking the user if they want to restart the program
                again = scan.next().toUpperCase(); 

                scan.close(); //closing the user input variable

            }

            catch (Exception e){ //catch statement not allowing for a user to error out
                System.out.println("An error has occured"); //telling the user that an error has occured
                continue; //continueing the program from where it left off
            }
        }
    }
}
