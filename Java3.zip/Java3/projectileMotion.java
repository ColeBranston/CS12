//Name: Cole Branston
//Date: 2023/01/01
//Purpose: program that calculates important projectile motion information based on a user's input

import java.util.Scanner; //importing the scanner library
import java.util.Arrays; //importing the arrays library

public class projectileMotion{ //initalizing the class
    public static void main(String[] args){ //initializing code 

        String again = "Y"; //setting again to Y for loop to begin

        while (again == "Y") { //while loop that allows for restart

            try{ //try statement that catches any error
                Scanner scan = new Scanner(System.in); //initalzing the scanner variable

                System.out.print("\nWhat is your initial velocity(m/s): "); //asking the user for their initial velocity
                double v = scan.nextDouble();

                System.out.print("What is your angle above the horizontal(degrees): "); //asking the user for their angle of the horizontal axis
                double angle = scan.nextDouble();

                System.out.print("What is the total time (seconds) that the projectile is in motion: "); //asking the user for time their projectile was in motion
                double t = scan.nextDouble();

                angle = Math.toRadians(angle); //converting the angle from degrees to radians

                double Vx = v*Math.cos(angle); //calculating the component vector (vertical)
                double Vy = v*Math.sin(angle); //calculating the component vector (horizontal)

                double xDistance = Vx * t; //calculating the distance that the projectile traveled in the horizontal direction
                double yDistance = (Vy * t) + (-9.81*(t*t))/2; //calculating the distance that the projectile moved in the vertical direction

                double fVx = Vx; //setting the final velocity in the horizontal direction to that of the intial velocity in the horizontal direction
                double fVy = Vy + (-9.81*t); //calculating the final vertical velocity based off vertical velocity plus the gravitational constant multiplied by the time the projectile is in motion

                Vx = (Math.round(Vx*100))/100; //rounding the horizontal velocity
                Vy = (Math.round(Vy*100))/100; //rounding the vertical velocity

                xDistance = (Math.round(xDistance*100))/100; //rounding the horizontal distance
                yDistance = (Math.round(yDistance*100))/100; //rounding the vertical distance

                fVx = (Math.round(fVx*100))/100; //rounding the final vertical velocity
                fVy = (Math.round(fVy*100))/100; //rouding the final horizontal velocity

                System.out.println("\nInitial Horizontal Velocity: "+Vx+" m/s"); //telling the user the intial horizontal velocity
                System.out.println("Horizontal Distance Travelled: "+xDistance+" m"); //telling the user the horizontal distance travelled
                System.out.println("Final Horizontal Velocity: "+fVx+" m/s"); //telling the user the final horizontal velocity

                System.out.println("\nInitial Vertical Velocity: "+Vy+" m/s"); //telling the user the inital vertical velocity
                System.out.println("Vertical Distance Travelled: "+yDistance+" m"); //telling the user the vertical distance travelled
                System.out.println("Final Vertical Velocity: "+fVy+" m/s"); //telling the user the final vertical velocity

                System.out.print("Do you want to restart the program? (Y/N): "); //asking the user if they want to restart the program
                again = scan.next();

                scan.close(); //closing the scanner

            }

            catch(Exception e){ //catch statement not allowing for erroring out
                System.out.println("\nAn Error has ocurred"); //telling the user that an error has occured
                continue; //continuing the program from where it left off

            }

        }
    }
}