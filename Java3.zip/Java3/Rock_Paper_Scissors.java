//Name: Cole Branston
//Date: 2023/01/02
//Purpose: Rock Paper Scissors simulartor

import java.util.Random; //importing random
import java.util.Scanner; //importing the scanner library
import java.util.Arrays; //importing the arrays library

public class Rock_Paper_Scissors { //initalizing the class

    static int [] rps(int num1, int num2, int [] counterArray){ //method taking in the user's choice and the computer's random choice as well as the array with the counters

        if ((num1 == 1) && (num2 == 1)){ //checking that the both players have chose rock
            System.out.println("You chose rock and so did your oponent, its a tie"); //telling the user the results
            counterArray[2] += 1; //increasing the tie counter by 1 each time

        }

        else if ((num1 == 1) && (num2 == 2)){ //checking that the player chose rock and the computer chose paper
            System.out.println("You chose rock, your oponent chose paper, you lose"); //telling the user the results
            counterArray[1] += 1; //increasing the computer's wins by 1 each time

        }

        else if ((num1 == 1) && (num2 == 3)){ //checking that the player chose rock while the computer chose scissors
            System.out.println("You chose rock, your oponent chose scissors, you win"); //telling the user the results
            counterArray[0] += 1; //increasing the players win by 1 each time

        }

        else if ((num1 == 2) && (num2 == 1)){ //checking that the player chose paper while the computer chose rock
            System.out.println("You chose paper, your oponent chose rock, you win"); //telling the user the results
            counterArray[0] += 1; //increasing the players win by 1 each time

        }

        else if ((num1 == 2) && (num2 == 2)){ //checking that the both players have chose paper
            System.out.println("You chose paper, and so did you oponent, its a tie"); //telling the user the results
            counterArray[2] += 1; //increasing the tie counter by 1 each time

        }

        else if ((num1 == 2) && (num2 == 3)){ //checking that the player has chosen paper while the computer has chosen scissors
            System.out.println("You chose paper, your oponent chose scissors, you lose"); //telling the user the results
            counterArray[1] += 1; //increasing the computer's wins by 1 each time

        }

        else if ((num1 == 3) && (num2 == 1)){ //checking that the player has chosen scissors while the computer has chosen rock
            System.out.println("You chose scissors, your oponent chose rock, you lose"); //telling the user the results
            counterArray[1] += 1; //increasing the computer's wins by 1 each time

        }

        else if ((num1 == 3) && (num2 == 2)){ //checking that the player has chosen scissors while the computer has chosen paper
            System.out.println("You chose scissors, your oponent chose paper, you win"); //telling the user the results
            counterArray[0] += 1; //increasing the players win by 1 each time

        }

        else if ((num1 == 3) && (num2 == 3)){ //checking that the both players have chose scissors
            System.out.println("You chose scissors, so did your oponent, its a tie"); //telling the user the results
            counterArray[2] += 1; //increasing the tie counter by 1 each time

        }

        System.out.println("\nPlayer1: "+counterArray[0]+"\nPlayer2: "+counterArray[1]+"\nTies: "+counterArray[2]); //telling the user each counter; player's wins, computer's wins, and the number of ties

        return counterArray; //returning the counter array
  
    }   

    public static void main(String[] args){ //initialzing the main method

        String again = "Y"; //intialzing the again variable for restart

        while (again == "Y"){ //while loop allowing for restart

            try{ //try statement now allowing for erroring out

                int [] counterArray = {0,0,0}; //initializing the counter array

                Random rand = new Random(); //initializing the random variable

                System.out.println("\nRock Paper Scissors"); //telling the user the name of the program
                System.out.println("--------------------");
                
                Scanner input = new Scanner(System.in); //initializing the scanner variable

                while ((counterArray[0] != 2) && (counterArray[1] != 2)){ //checking that neither the player or the computer have won

                    int num2 = rand.nextInt(1,3); //getting a random number from 1 to 3

                    System.out.print("\nRock, Paper, or Scissors (1, 2, 3): "); //asking the user their choice of rock, paper, or scissors
                    int num1 = input.nextInt();

                    while ((num1 < 1) || (num1 > 3)){ //checking that the user has entered valid input

                        System.out.println("\nEnter a valid chose"); //telling the user to input a valid chose

                        System.out.print("\nRock, Paper, or Scissors (1, 2, 3): "); //asking the user their choice of rock, paper, or scissors
                        num1 = input.nextInt();

                    }

                    counterArray = rps(num1, num2, counterArray); //calling the function and getting the new counter array

                }

                if (counterArray[0] == 2){ //checking that player1 won the game
                    System.out.println("\n-------------------------------------"); //telling the user that they have won
                    System.out.println("Congratulations Player1, you win");
                    System.out.println("-------------------------------------");

                }

                else{ //checking that the computer won the game
                    System.out.println("\n----------------------------------------------------"); //telling the user that they have lost
                    System.out.println("Congratulations Player2, you win, Player1 you lose");
                    System.out.println("----------------------------------------------------");

                }

                System.out.print("\nDo you want to restart the program? (Y/N): "); //asking the user if they want to restart the program - making their response upper case
                again = input.next().toUpperCase();

                input.close(); //closing the input variable

            }

            catch (Exception e){ //catch statement now allowing for erroring out
                System.out.println("\nAn error has occurred"); //telling the user that an error has occured
                continue; //continueing the program from where it left off

            }
            
        }
    }
}
