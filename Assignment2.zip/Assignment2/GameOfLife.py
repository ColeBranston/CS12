# Name: Cole Branston
# Date: 2022/10/23
# Purpose: Create a program that simulates the game of life

import random #importing random

oldIndex = [] #initializing the old index for 

counterList = [[0 for x in range(20)]for y in range(20)] #initializing the counter List

genList = [["-"for x in range(20)]for y in range(20)] #initializing the first game of life with dead cells

def lifeCheck(): #creating the life check function will check the radius of the live or dead cells and count those that are alive

    for x in range(len(genList)): #itterating through the genList (game of life)
        for y in range(len(genList[x])):

            neighbours = 0 #defining/redefining neighbours as 0

            if x < 19: #checking that the x is below 19

                if genList [x + 1][y] == "X": #checking for live cells below the actual cell thats going to be changed

                    neighbours += 1 #adding 1 to the counter

                if y > 0: #checking if the y index is greater than 0

                    if genList [x + 1][y - 1] == "X": #checking both down and behind the cell being checked

                        neighbours += 1 #adding to the counter

                
                if y < 19: #checking if the y is less than 19
                    if genList [x + 1][y + 1] == "X": #checking below and infron the cell the thats getting changed

                        neighbours += 1 #adding to the counter

            if x > 0: #checking if the counter is above 0

                if genList [x - 1][y] == "X": #checking if the cell below the cell being changed is alive

                    neighbours += 1 #adding to the counter

                if y < 19: #checking if the y is below 19

                    if genList [x - 1][y + 1] == "X": #checking if below and infront of the cell being checked is alive

                        neighbours += 1 #adding to the counter

                if y > 0: #checking if the y index is above 0

                    if genList [x - 1][y - 1] == "X": #checking below and behind the cell thats being changed if the cell in question is alive

                        neighbours += 1 #adding to the counter

            if y > 0: #checking if the y is above 0
                
                if genList [x][y - 1] == "X": #checking if the cell behind the cell being changed is alive

                    neighbours += 1 #adding to the counter

            if y < 19: #checking if the y is less than 19
                if genList [x][y + 1] == "X": #checking if the cell infront of the cell being changed is alive

                    neighbours += 1 #adding to the counter

            counterList[x][y] = neighbours #changing the counter spot in the counter List

def arrayPrint(array):
    for x in range(len(array)):
        for y in range(len(array[x])):
            print(array[x][y], end = " ")

        print()

while True: #while loop whos purpose is for the error checking (try and except)

    try: #try statement now allowing for erroring out

        liveCells = int(input("How many live cells do you want? (1-400): ")) #asking the user how many live cells do they want in their game of life

        while liveCells >400 or liveCells <0: #checking the user put in the correct parameters for the number of live cells
            liveCells = int(input("\nHow many live cells do you want? (1-400): ")) #asking the user how many live cells they want based on if there original didn't meet the requirements

        for x in range(liveCells): #itterating throught the liveCells list based on its length

            coords = [random.randint(0, 19), random.randint(0,19)] #assinging certain random indexs

            while coords in oldIndex: #checking if the assinged coords are in the already used list (oldIndex)
                coords = [random.randint(0, 19), random.randint(0,19)] #if the coords are in the used list, create new coords and rinse and repeat

            oldIndex.append(coords) #add the new coords to the Old Index list for later checking

            genList[coords[0]][coords[1]] = "X" #changing a random cell in the game of life array (genList) to alive

        while True: #infinite Loop

            lifeCheck() #calling the function

            arrayPrint(genList) #calling the function

            for x in range(len(genList)): #itterating throught the game of life array based on its length
                for y in range(len(genList[x])):
                    if genList[x][y] == "X": #checking if the GOL cell is alive
                        if counterList[x][y] < 2: #checking the same index in the counter List to determine what it should do
                            genList[x][y] = "-" #killing the concerned cell

                        elif counterList[x][y] <= 3: #checking the same index in the counter List to determine what it should do
                            pass #keeps it alive

                        elif counterList[x][y] > 3: #checking the same index in the counter List to determine what it should do
                            genList[x][y] = "-" #killing the concerned cell
                            
                    else: #checking if the cell is dead
                        if counterList[x][y] == 3: #checking the same index in the counter List to determine what it should do
                            genList[x][y] = "X" #changing the concerned cell to an alive cell
                
            input("\nPress enter to see the next generation") #telling the user to press enter to see the next generation

    except: #except statement now allowing for erroring out
        continue #continuing the from where the program left off