def read(file):

    fileList = []

    #opening the text file
    fileTXT = open(file, "r")

    #reading the text file
    fileLine = fileTXT.readline()

    #checking if a line isn't blank, adding to the list, reading next line
    while fileLine != "":

        #stripping read lines of syntax
        fileLineStripped =fileLine.rstrip("\n") #adding stripped lines to a list
        fileLineStripped = fileLine.rstrip('""')
        fileList.append(fileLineStripped)

        #reading the next line
        fileLine = fileTXT.readline()

    #closing doc
    fileTXT.close()

    return fileList

def write(file, var):

    fileTXT = open(file, "a")

    fileTXT.write("\n"+str(var))

    #closing doc
    fileTXT.close()

    

