# Name: Cole Branston
# Date: 2022/10/17
# Purpose: Create a program that allows users to login or register with a username and password

#importing all functions from ReadWrite
from ReadWrite import *

#importing time -for added effect
import time

#defining the file I want read and written into
file = 'userpassDatabase.txt'

#initiailing again for later restart
again = "Y"

#while loop that uses the again variable in order to restart the program
while again == "Y":

    #try statement that ensures no erroring out
    try:

        #defining the incorrect variable for locking the user out
        incorrect = 3

        #printing the opttions
        print("\n1. Login\n2. Register")

        # asking the user what they want to choose
        choice = int(input("\n"))

        # checking if the users choice was login
        if choice == 1:

            # loop that asks the user for there username and password
            while True: 

                #asking the user for there username and password
                print("\n------------------------------")
                username = input("What is your username: ")
                password = input("What is your password: ")
                print("------------------------------")

                #defining the username password dictionary
                userpass = str({username : password})

                # calling the function
                fileList = read(file)

                #checking if the usernamem and password is in the database
                if userpass in fileList:

                    # telling the user that they have been granted access
                    print("\n-------------------------")
                    print("You are granted access")
                    print("-------------------------")

                    #ending the loop
                    break

                #telling the user that they have got there username or password wrong and telling them the number of tries hey have left
                else: 
                    print("\n********************************************************************")
                    print("Incorrect username or password, you have", incorrect -1, "try(s) left")
                    print("********************************************************************")

                    #decreasing the number of tries that the user has
                    incorrect -= 1

                #checking if the user has inputed an incorrect username and password thats wrong more than 3 times
                if incorrect == 0:

                    # Telling the user that they have been locked out
                    print("\n**********************")
                    print("You are locked out in")
                    print("**********************")

                    #stalling the terminal for dramatic effect
                    time.sleep(1)

                    #printing countdown
                    print("\n3")

                    #stalling the terminal for dramatic effect
                    time.sleep(1)

                    #printing countdown
                    print("2")

                    #stalling the terminal for dramatic effect
                    time.sleep(1)

                    #printing countdown
                    print("1")

                    #stalling the terminal for dramatic effect
                    time.sleep(1)

                    # breaking the loop
                    break

        #checking if the user wants to register
        elif choice == 2: 

            #Asking the user there username and password
            print("\n------------------------------")
            username = input("Username: ")
            password = input("Password: ")
            print("------------------------------")

            #Assigning the username and password to a dictionary
            userpass = {username : password}

            #writing there username and password into the database
            write(file, userpass)

            #telling the user that they have been welcomed to the database
            print("\nWelcome", username)

        #asking the user if they want to restart the program
        again = input("\nDo you want to restart the program? (Y/N): ").upper()

    #except statement now allowing for erroring out
    except:

        #continuing from where it left off
        continue