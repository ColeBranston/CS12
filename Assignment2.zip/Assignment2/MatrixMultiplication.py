# Name: Cole Branston
# Date: 2022/09/29
# Purpose: Create a program that does matrix multiplication

#initializing the again variable for later restart of the program
again = "Y"

#creating function for final output
def finalOutput(matrixName):

        #outputting the final statement for each matrix
        print("---", "---".rjust(len(matrixName[0])*5))
        for x in range(len(matrixName)):

            print("|", end = "")

            for y in range(len(matrixName[x])):
                print(str(matrixName[x][y]).rjust(5), end = "")

            print("  |")
        print("---", "---".rjust(len(matrixName[0])*5))

#while loop allowing for restart
while again == "Y":

    #try statement not allowing the program to error out
    try: 

        #read and assign the text files to an array
        matrixArr = []
        checkList = []
        measurements = []

        #opening the text file
        matrix = open("MatrixAandB.txt", "r")

        #reading the text file
        matrixLine = matrix.readline()

        #checking if a line isn't blank, adding to the list, reading next line
        while matrixLine != "":

            #stripping read lines of syntax
            matrixlineStripped = matrixLine.rstrip("\n") #adding stripped lines to a list
            matrixArr.append(matrixlineStripped)

            #reading the next line
            matrixLine = matrix.readline()

        #closing doc
        matrix.close()

        #itterate through each item splitting as you go, checking for 2 numbers (len of list == 2) and converting those numbers to create two main lists
        for x in matrixArr:

            #splitting the read file in to the checkList
            checkList.append(x.split())
            
        #clearing the checkList of it's measurement, but adding them to a separate list    
        for x in checkList: 

            #checking of each list in the array is 2
            if len(x) == 2:

                #adding the list to a seprate array
                measurements.append(x)
                
                #removing that list from the array
                checkList.remove(x)

        #creating matrix1 and matrix2 
        matrix1 = [checkList[x]for x in range(int(measurements[0][0]))]
        matrix2 = [checkList[x]for x in range(int(measurements[0][0]), len(checkList))]

        #creating the final arr
        result = [[sum((int(matrix1[i][k]) * int(matrix2[k][j]))for k in range(len((matrix2))))for j in range(len(matrix2[0]))]for i in range(len(matrix1))]
        
        #telling the user the title of the program
        print("\n-----------------------")
        print(" Matrix Multiplication")
        print("-----------------------")

        finalOutput(matrix1) #Calling function with parameter

        #outputting the multiplication symbol
        print("X".rjust(10))

        finalOutput(matrix2) #Calling function with parameter

        #outputting the equals symbol
        print("=".rjust(10))

        finalOutput(result) #Calling function with parameter

        #asking the user if they want to restart the program
        again = input("\nWould you like to restart the program? (Y/N): ").upper()

    #except statement not allowing for the program to error out
    except:

        #telling the user that an error has occured
        print("\nAn error has occurred, please try again")

        #continuing the program from where it left off
        continue