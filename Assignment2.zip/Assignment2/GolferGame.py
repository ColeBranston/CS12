# Name: Cole Branston
# Date: 2022/09/30
# Purpose: Create a program that makes a golfer game

#importing random library
import random

#initializing again for later restart
again = "Y"

def determineWinner():

    #checking who won each hole out of the total 9 holes
    for x in range(9):

        #adding each hole score to the comparitive list to check who won
        comparitiveList = [golferList[0][x],golferList[1][x],golferList[2][x],golferList[3][x]]
        
        #finding the smallest score in the list
        winVal = min(comparitiveList)

        #checking if anyone tied that min value
        if comparitiveList.count(winVal) == 1:

            #loop intterating through the range 0, 3 for later list item calls
            for i in range(4):

                #checking if golfer 1 won the first hole
                if winVal == golferList[i][x]:

                    #adding to which they hole they won to a list
                    holeList[i].append(x+1)

            #clearing the comparitive list
            comparitiveList.clear()

        #checking if there was a tie
        else:

            #cleating the list
            comparitiveList.clear()
    

#while loop used for restart
while again == "Y":

    #try statement now allowing for erroring out
    try: 

        #creating the main array
        golferList = [[random.randint(1,10) for x in range(9)] for x in range(4)]

        #defining the comparitive list which I will use to find out who won the hole
        comparitiveList = []

        #list of holes that each golfer won 
        holeList = [[],[],[],[]]

        #calling the function
        determineWinner()

        #telling the user the title of the program
        print("----------------------".rjust(90))
        print("Golf Game Application".rjust(90))
        print("----------------------".rjust(90))

        #printing the holes
        print("Hole 1".rjust(25),"Hole 2".rjust(15),"Hole 3".rjust(15),"Hole 4".rjust(15),"Hole 5".rjust(15),"Hole 6".rjust(15),"Hole 7".rjust(15),"Hole 8".rjust(15),"Hole 9".rjust(15))

        #loop which outputs the player and there respective scores
        for x in range(4):

            #outputting the player name and number
            print("\nPlayer"+str(x+1),end="")

            #loop which prints off the player scores per hole
            for i in range(9):

                #outputs the scores for each player
                print(str(golferList[x][i]).rjust(16), end = "")

        for x in range(4):
            #prints how many holes player1 won 
            print("\n\nPlayer", x+1, "Won", len(holeList[x]), "Hole(s): ", end = " ")

            #loop which prints which hole player1 won using the numbers in the holeList for player 1 
            for i in holeList[x]: 

                #outputting the holes that player won
                print("Hole", i, end = " ")

        #again statement allowing for the user to restart the program
        again = input("\n\nDo you want to restart the program? (Y/N): ").upper()

    #except statement now allowing for erroring out
    except:

        #telling the user that an error has occured
        print("\nAn error has occured, please try again")

        #continueing the program from where it left off
        continue