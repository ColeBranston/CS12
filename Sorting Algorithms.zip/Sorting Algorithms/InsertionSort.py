from ReadWrite import read #importing my read function

import time #importing the time function

List1 = read("Num1000.txt") #calling the function by returning the read doc list with 1000 nums

List2 = read("num10000.txt") #calling the function by returning the read doc list with 10000 nums

mainList1 = [int(List1[x]) for x in range(len(List1))]
mainList2 = [int(List2[x]) for x in range(len(List2))]

def insertionSort(arr): #defining the function
    comparisons=0 #setting the first counter to 0 (Comparisons)
    swaps=0 #setting the second counter to 0 (Swaps)

    for i in range(1, len(arr)): #itterating through a range based on the 1 to the length of the list
        comparisons+=1 #increasing the numbre of comparisons by 1
        key = arr[i] #setting the key variable to the elemtn, arr[i]

        j = i-1 #setting j to the i-1

        while j >=0 and key > arr[j]: #continueing the loop as long as j is greater than or equal to 0 and the key variable is less than the elemtn, arrj[]

            swaps+=1 #increasing the number of swaps by 1 each time

            arr[j+1] = arr[j] #swapping the two elements
            j -= 1 #decreasing the j variable by 1 each time
        arr[j+1] = key #setting the element, arr[j+1] to the key variable
    
    return comparisons, swaps #returning the comparisons and swaps for later use

time1 = time.time() #gettting the time before the algorithm is used
comparisons, swaps = insertionSort(mainList1) #calling the function
time2=time.time() #getting the time after the algo is used

print("Comparisons: ", comparisons, "\nSwaps: ", swaps, "\nTime: ", (time2 - time1) * 1000) #telling the user the number of comparions, swaps, and the difference of time taken to swap in milliseconds

print(mainList1) #outputting the sorted list