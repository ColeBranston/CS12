# Name: Cole Branston
# Date: 2022/11/29
# Purpose: Recreate the selection sort

from ReadWrite import read #importing the function to read the text file

import time #importing time

readDoc1 = read("Num1000.txt") #reading the 1000 num doc
readDoc2 = read("Num10000.txt") #reading the 10000 num doc

mainList1 = [int(readDoc1[x]) for x in range(len(readDoc1))] #making the first List (1000)
mainList2 = [int(readDoc2[x]) for x in range(len(readDoc2))] #making the second List (10000)

def Select():
    counter1 = 0 #initializing the counter as 0 (comparisons)
    counter2 = 0 #initializing the swaps counter as 0

    time1 = time.time() #calling the time before the sort occurs

    for x in range(len(mainList1)): #itterating through the first list by its length
        for y in range(x+1, len(mainList1)): #itterating again through the list by its length 

            counter1 += 1 #increasing the counter1 by 1 each time

            if mainList1[x] > mainList1[y]: #checking if element is less than the one in the second for loop

                counter2 += 1 #increasing the number of swaps each time

                val1 = mainList1[x] #assigning variables to each values so I can change them


                mainList1[x] = mainList1[y] #changing each element
                mainList1[y] = val1 #changing each element

    time2 = time.time() #calling the time after the sort has occured

    print("Selection 1000 Numbers: ", time2-time1, "seconds and", counter1, "comparisons", counter2, "swaps") #telling the user the numbers they sorted through, the time it took to sort, and the number of comparisons

    print(mainList1) #telling the user the sorted list

Select()



