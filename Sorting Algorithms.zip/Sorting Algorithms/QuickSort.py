
from ReadWrite import read #importing my read function

import time #importing the time library
 
List1 = read("Num1000.txt") #calling the my read function; returning the first list

List2 = read("Num10000.txt") #calling my read function; returning the second list

def quicksort(low,high): #intializing the quick sort function
    if low < high: #checking that the low variable is less than the high variable
        new=(low,high) #setting the new variable to a tuple(low and high)
        quicksort(low, new-1) #calling the function with a decrease in the new variable by 1 
        quicksort(new+1,high) #calling the function with an increase in the new variable

def partition(left, right): #initializing the partition function using the left and right variables as paremeters
    sep=list[left] #defining the sep variable as the list of the left variable
    direct="moveleft" #assigning the direct variable to move left
    while left < right: #continueing the loop as long as the left variable is less than the right
        if direct == "moveleft": #checking that the direct variable is equal to moveleft
            while (list[right]>= sep) and (left < right): #continuing the lopp a slong as the list[right] elemetn is greather than or equal to the sep variable and the left variable is less than the right variable
                right = right - 1 #subtracting 1 from the right variable each time
                list[left]= list[right] #setting the list of the left variable equal to the list of the right variable
                direct = "moveright" #setting teh direct variable to moveright
        else: #checking if the direct variable doesn't equal moveleft
            while (list[left]<=sep) and (left < right): #continuing the lopp as long as the list of the left variable is less than or equal to the sep variable and that the left variable is less than the right variable
                left=left+1 #increasing the left variable by 1 each time
            list[right]=list[left] #setting the list of the right variable to the list of the left variable
            direct="moveleft" #setting the direct variable to moveleft
           
    location=left #setting the location to the left variable
    list[location]=sep #setting the list of the location variable to the sep variable
    return location #returning the location variable

def partition(array, low, high): #initialzing the partition function with the array, high, and low as its paremeters

    pivot = array[high] #defining the pubot as the element of array[high]

# pointer for greater element
    i = low - 1

    for j in range(low, high): #itterating through the range between the low and the high
        if array[j] >= pivot: #checking tha the elemtn array[j] is greater than or equal to the pivot

            i = i + 1 #increasing the pointer by 1 each time

            (array[i], array[j]) = (array[j], array[i]) #setting the tuple (array[i], array[j]) equal to the (array[j], array[i] tupple)

    (array[i + 1], array[high]) = (array[high], array[i + 1]) #setting the (array[i + 1], array[high]) tuple to the (array[high], array[i + 1]) tuple

    return i + 1 #returning the pointer plus 1

def quickSort(array, low, high): #initializing the quick sort2 function
    if low < high: #checking that the low variable is less than the high variable

        pi = partition(array, low, high) #calling the pi variable from the partition function 

        quickSort(array, low, pi - 1) #calling the quickort2 function using hte array, low, and pi decreased by 1 each time as paremeters

        quickSort(array, pi + 1, high) #calling the quicksort2 function using the array, pi increase by 1, and the high as paremeters

quickSort(List1, 0, len(List1) - 1) #calling the quick sort function


print(List1) #telling the user the final sorted list