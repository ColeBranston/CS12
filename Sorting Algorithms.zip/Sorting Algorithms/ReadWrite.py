def read(file):

    fileList = []

    #opening the text file
    fileTXT = open(file, "r")

    #reading the text file
    fileLine = fileTXT.readline()

    #checking if a line isn't blank, adding to the list, reading next line
    while fileLine != "":

        #stripping read lines of syntax
        fileLineStripped =fileLine.rstrip("\n") #adding stripped lines to a list
        fileList.append(fileLineStripped)

        #reading the next line
        fileLine = fileTXT.readline()

    #closing doc
    fileTXT.close()

    return fileList #returning the read file in a list

def write(file, var): #defining the write function using the file

    fileTXT = open(file, "a") #opening the file

    fileTXT.write("\n"+str(var)) #writing into it

    #closing doc
    fileTXT.close() #closing the file

    

