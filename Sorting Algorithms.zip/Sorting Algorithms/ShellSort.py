import time #importing time
from ReadWrite import read #importing the read function from my readwrite file

List1 = read("Num1000.txt") #reading the 1000 number doc and assigning it to a list

List2 = read("num10000.txt") #reading the the 10000 number doc and assigning it a list

mainList1 = [int(List1[x]) for x in range(len(List1))] #initalizing the 1000 num list
mainList2 = [int(List2[x]) for x in range(len(List2))] #initialzing the 10000 num list

def shell_sort(array): #Initializing the shell sort function
    comparisons = 0 #setting the comparison counter to 0
    swaps = 0 #setting the swaps counter to 0
    G = len(array)//2 #setting the length of the array//2 to the variable G

    while G >= 1: #continueing the code as long as half of that arrays length is greater than or equal to 1
        var = True #setting the boolean variable to true

        while var == True: #checking that the bool is true and contineuing the code 
            var = False #setting the bool to false
            
            for x in range(len(array)-G): #itterating through the range from 0 to the length of the array subtract half of the arrays legnth

                comparisons += 1 #increasing the comparisons counter by 1 each time

                if array[x] < array[x+G]: #checking if the element in greather than or less than the next element in the list
                    swaps += 1 #increasing the swaps counter by 1 each time
                    var = True #setting the bool to true to show that a swap has occured
                    t = array[x] #setting the first element to the variable t
                    array[x] = array[x+G] #setting the first element to the second element
                    array[x+G] = t #setting the second element to the original t variable
        
        G //= 2 #floor dividing half of the original lists length by 2 each time

    return comparisons, swaps #returning the comparisons and swaps

t1 = time.time() #getting the time before sorting
comparisons, swaps = shell_sort(mainList1) #calling the function
t2 =time.time() #getting the time after the sorting

print("Comparisons: ", comparisons, "\nSwaps: ", swaps, "\nTime: ", (t2-t1)*1000) #telling the user the number of comparisons, swaps, and time it took to sort in milliseconds

print(mainList1) #outputting the sorted list

