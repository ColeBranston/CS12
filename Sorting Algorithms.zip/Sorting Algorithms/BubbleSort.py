# Name: Cole Branston
# Date: 2022/12/02
# Purpose: Create a prpgram uses bubble sort

from ReadWrite import read #importing my read function from ReadWrite

import time #importing time

readDoc1 = read("Num1000.txt") #calling the function for the 1000 numbers doc
readDoc2 = read("num10000.txt") #calling the function for the 10000 numbers doc

mainList1 = [int(readDoc1[x]) for x in range(len(readDoc1))] #creating the first List of numbers
mainList2 = [int(readDoc2[x]) for x in range(len(readDoc2))] #creating the second list of numbers

def bubble():
    x1=time.time() #getting the time before sorting

    counter1=0 #intializing each counter for comparisons and swaps
    counter2=0 
    bool=True #initializing the bool variable

    while bool==True: #continueing to sort based on if the bool is True
        bool = False #setting the bool to False
        for j in range(len(mainList1)-1): #itterating through the mainList based on its length-1

            counter1+=1 #increasing the comparisons by 1 each time

            if mainList1[j]<mainList1[j+1]: #checking if the first element is greater than or less than the second element

                counter2+=1 #increasing the swaps counter by each time
                bool=True #setting the bool to True
                t=mainList1[j] #setting the first element to a variable
                mainList1[j]=mainList1[j+1] #swapping values
                mainList1[j+1]=t #swapping values

    x2 = time.time() #getting the time after the sort has occurred 

    print(counter1, counter2) #telling the user the swaps and comparisons

    print((x2-x1)*1000) #telling the user the time it takes to sort in milliseconds

    print(mainList1) #telling the user the sorted list

bubble()