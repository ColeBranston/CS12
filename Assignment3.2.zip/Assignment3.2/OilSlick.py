# Name: Cole Branston
# Date: 2022/11/22
# Purpose: Create a program that finds oil slicks and returns the largest and where its located

indexSize = [[], []] #initialzing the size and index array for later use on finding the largest spill and where its located
counter = 0 #initializing hte counter as 0

def slicks(row,col): #initlizing the recursive function

    global counter #globaling the counter to increase the scope of the function

    if txt[row][col] == "O": #checking if the row and column in the txt array is a *

        txt[row][col] = " " #replacing the O with a space
        counter += 1 #increasing the counter based on the number of O in the oil splill
        slicks(row,col+1) #calling the function looking infront of it
        slicks(row+1,col) #calling the function looking below the space
        slicks(row,col-1) #calling the function looking behind 
        slicks(row-1,col) #calling the function looking above
        slicks(row+1, col-1) #calling the function looking at the bottom left corner
        slicks(row+1, col+1) #calling the function looking at the bottom right corner
        slicks(row-1, col-1) #calling the function looking at the top left corner
        slicks(row-1, col+1) #calling the function looking at the top right corner

def readTXT(): #defining the function to read the file
    inFile = open("slicks.txt","r") #opening the file
    line = inFile.readline().rstrip("\n") #reading the file
    row = 0 #defining the row as 0

    while line != "": #checking if the line has any contents
        txt.append([line[0]]) #adding the each character in the line to the array

        for x in range(1,len(line)): #itterating through the length of the array by its length
            txt[row].append(line[x]) #adding each character to the line

        row = row + 1 #increasing the counter
        line = inFile.readline().rstrip("\n") #reading the next line in the file

    inFile.close() #closing the file
    
txt = [] #initialing the array

readTXT() #calling the function

for x in range(len(txt)): #itterating through the array by its length
    for y in range(len(txt[x])): #itterating through the length of the each list in the array 
        print(txt[x][y], end = " ") #printing each line

    print() #making a space

for x in range(len(txt)): #itterating through the text array baesd on the number of rows 
    for y in range(len(txt[x])): #itterating through the text array based on the number of items in each row

        if txt[x][y] == "O": #checking if the character is an O representing the oil 

            slicks(x, y) #calling the function with the location of the oil
            indexSize[0].append(counter), indexSize[1].append((x, y)) #adding the counter and location of that spill to the indexSize list

            counter = 0 #resetting the counter as 0

print("The largest spill is: ", max(indexSize[0]), "Cells" '\nThe uppermost, leftmost co-ordinates of the largest slick are: ', indexSize[1][indexSize[0].index(max(indexSize[0]))]) #printing the final statement telling the user what the largest oil spill is and where its located. 

#Note: although it looks more complicated I hoped that it would be more efficient just to use the index of the max in the first list in the array as the index of the location list in the array




