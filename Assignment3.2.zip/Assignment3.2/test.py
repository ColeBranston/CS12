txt = []

def ReadDoc():
    inFile = open("Blobs.txt", "r")
    line = inFile.readline().rstrip('\n')
    row = 0

    while line != "":
        txt.append([line[0]])

        for x in range(1, len(line)):
            txt[row].append(line[x])

        row += 1
        line = inFile.readline().rstrip('\n')

    inFile.close()

def removeBlob(row, col):
    if txt[row][col] == "*":
        txt[row][col] = " "
        removeBlob(row+1, col)
        removeBlob(row, col+1)
        removeBlob(row-1, col)
        removeBlob(row, col-1)

ReadDoc()

while True:
    for x in range(len(txt)):
        for y in range(len(txt[x])):
            print(txt[x][y], end =" ")

        print()

    row = int(input("what is your row that you want to start to delete?: "))
    col = int(input("what col do you want to start to delete?: "))
        
    removeBlob(row, col)
    