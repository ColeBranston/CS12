# Name: Cole Branston
# Date: 2022/11/22
# Purpose: Create a program that finds blobs and removes them

def blobs(row,col): #initlizing the recursive function

    if txt[row][col] == "*": #checking if the row and column in the txt array is a *
        txt[row][col] = " " #replacing the asterisk with a space
        blobs(row,col+1) #calling the function looking infront of it
        blobs(row+1,col) #calling the function looking below the space
        blobs(row,col-1) #calling the function looking behind 
        blobs(row-1,col) #calling the function looking above

def readTXT(): #defining the function to read the file
    inFile = open("Blobs.txt","r") #opening the file
    line = inFile.readline().rstrip("\n") #reading the file
    row = 0 #defining the row as 0
    while line != "": #checking if the line has any contents
        txt.append([line[0]]) #adding the each character in the line to the array
        for x in range(1,len(line)): #itterating through the length of the array by its length
            txt[row].append(line[x]) #adding each character to the line
        row = row + 1 #increasing the counter
        line = inFile.readline().rstrip("\n") #reading the next line in the file
    inFile.close() #closing the file
    
txt = [] #initialing the array

readTXT() #calling the function

while True: #infinite loop

    try: #checking for erroring out

        for x in range(19):
            print(x, end = "")

        print(20) #printing the number 20

        for x in range(len(txt)): #itterating through the array by its length
            print(x, end = "")
            for y in range(len(txt[x])): #itterating through the length of the each list in the array 
                print(txt[x][y], end = "") #printing each line

            print() #making a space

        col = int(input("What column would you like?: ")) #asking the user for their column
        row = int(input("What row would you like?: ")) #asking the user for their row

        while txt[row][col] != "*": #checking if there is a blob in the designated area
            print("\nThere is no blob there") #telling the user that their is not blob in their specific area

            col = int(input("What column would you like?: ")) #asking the user for their column
            row = int(input("What row would you like?: ")) #asking the user for their row

        blobs(row, col) #calling the recursive function

    except: #checking for erroring out
        print("\nTry Again") #telling the user that an error has occurred
        continue #continuing the function from where it left off

