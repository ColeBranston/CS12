# Name: Cole Branston
# Date: 2022/10/31
# Purpose: Create the fibonacci series using recursion

#defining the recursive function
def fibonacci(num):
    if num <= 2: #base case
        return 1 #returned number

    else: #checking if the num value isn't the base case
        return fibonacci(num - 1) + fibonacci(num - 2) #returning the sum of the previous numbers

while True: #infinite loop which will continue the program until broken
 
    try: #try statement to ensure that the user doesn't error out
        #Telling the user the purpose of the program
        print("\nFibonacci numbers are listed as follows:\n\t1, 1, 2, 3, 5, 8, 13, 21, 34 ...")
        print("\twhere:  F(1) = 1\n\t\tF(2) = 1\n\t\tF(n) = F(n-1) + F(n-2) for all n>=3")
        print("\nThis program uses recursion to find the nth fibonacci number")
        #Ensuring the user the enters proper values

        num = int(input("\nWhat term would you like to see? (negative number to quit the program): ")) #asking the user for there term
 
        if num < 0: #checking that the number is negative
            break #breaking the loop

        val = fibonacci(num) #calling the function

        print("\nF("+str(num)+") = ", val) #telling the user their turn and the nth term

    except: #except statement to ensure that the user doesn't error out
        print("\nAn error has occured") #telling the user that an error has occurred
        continue #continueing the program from where it left off
        

