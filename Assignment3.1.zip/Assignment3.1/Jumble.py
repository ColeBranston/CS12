# Name: Cole Branston
# Date: 2022/11/07
# Purpose: Create a program that finds every possible character combination inputed by the user using recursion

again = "Y"

def jumble(s,s2): # defining the jumble function

    if len(s) < 1: #checking if the length of the first character storage has reached the basecase
        print(s2, end=" ") #outputting s2

    else: #checking if the length of the first character storage is not the base case

        for x in range(len(s)): #itterating through the first character storage based on its length
            jumble(s[0:x] + s[x+1:],s2+s[x]) #calling the function with the first storage as the previous first storgae except the first, x and x+1 indexes. Calling the second character storage as the previous storage + the

while again == "Y": #running the code as long as the user wants to (through the choice variable)

    print('Jumble') # title
    print('------')

    string = input("Enter a string of characters: ").upper() # asking for the string 

    jumble(string,"") #calling the function with the user input as the character storage and a blank string as the second character storage

    again = input("\n\nDo you want to restart the program? (Y/N): ").upper() #asking the user if they want to restart the program