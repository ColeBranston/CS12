# Name: Cole Branston
# Date: 2022/11/14
# Purpose: Add lists to the towers of hanoi code so that after each move in the terminal the pegs are printed

def hanoi(Fpeg, Tpeg, Tmpeg, FromList, ToList, TmpList, numdiscs): #initalizing the function
                                                                                                                                                                                                                 
    if numdiscs == 1: #checking that the number of discs is 1
        print("Move disc", 1,"from",Fpeg,"to",Tpeg) #telling the user to move disc 1 from a peg to a peg
        ToList.append(FromList.pop()) #adding the removed disk from the fromList to the ToList

        print("Peg A:", *AList) #displaying peg A
        print("Peg B:", *BList) #displaying peg B
        print("Peg C:", *CList) #displaying peg C
        input("Press enter to see next move >>>") #telling the user to press enter to see the next move

    else: #checking that the number of discs is a number other than 1 
        hanoi(Fpeg, Tmpeg, Tpeg, FromList, TmpList, ToList, numdiscs-1) #calling the function
        print("Move disc",str(numdiscs),"from",Fpeg,"to",Tpeg) #telling the user where each peg is being moved
        ToList.append(FromList.pop()) #adding the removed, last disk from the FromList to the ToList

        print("Peg A:", *AList) #displaying peg A
        print("Peg B:", *BList) #displaying peg B
        print("Peg C:", *CList) #displaying peg C
        input("Press enter to see next move >>>") #telling the user to press enter to see the next move

        hanoi(Tmpeg, Tpeg, Fpeg, TmpList, ToList, FromList, numdiscs-1) #calling the function with a change to the num discs parameter

AList = [] #initalizing the AList
BList = [] #initalizing the BList
CList = [] #initalizing the CList
A, B, C = "A", "B", "C" #defining the A, B, and C variables

Discs = int(input("How many discs do you want: ")) #asking the user for the number of discs they want

for x in range(Discs, 0, -1): #initialzing the first peg by looping through a range of numbers from the number of discs to 0
    AList.append(x) #adding each disk to the first peg (AList)

#Displaying the contents of the pegs before they are moved around  
print("\nPeg A:", *AList, "\nPeg B:", *BList, "\nPeg C:", *CList) #displaying each peg
input("Press enter to see next move >>>") #telling the user to press enter to see the next move

hanoi(A, C, B, AList, CList, BList, Discs) #Calling the hanoi function with the original paremeters

print("\nCongratulations! You have finished the Towers Of Hanoi") #telling the user that the towers of hanoi have been moved