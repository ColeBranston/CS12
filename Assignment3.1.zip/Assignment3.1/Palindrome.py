# Name: Cole Branston
# Date: 2022/11/08
# Purpose: Create a program that checks whether a string is a palindrome

#intitializing the function
def palindromeCheck(n):
    if len(n) <= 1: #checking that the length of the string is less than 1 
        return True #returning True 

    elif n[0] == n[-1]: #checking if the last charcter of the string is the same as the first
        return palindromeCheck(n[1:-1]) #returning the function with the word's first and last letters removed

    else: #checking if the first and last letters are not the same
        return False #returning false

again = "Y" #setting the again varaible to Y

while again == "Y": #while loop that allows for restart as long as again is Y

    print("\nPandrome Checker") #telling the user the title of the program
    print("-----------------")

    #telling the user the purpose of the program
    print("\nThis program checks whether a word or phrase is a palindrome. \nA palindrome is a word or phrase that is spelt the same backwards as it is forwards\nEg. Dad is a palindrome, Ethan Greene is not")

    n=str(input("\nEnter a word or phrase: ")).upper() #asking the user for their word or phrase
    n2 = n.replace(" ", "") #setting a new variable to the sentence but with all the spaces removed

    if palindromeCheck(n2): #checking if the function is true
        print(n,"is a palindrome ") #telling the user that their word or phrase is a palindrome
    else: #checking if the function is false
        print(n,"is not a palindrome") #telling the user that their word or phrase is not a palindrome

    again = input("\nDo you want to restart the program? (Y/N): ").upper() #asking the user if they want to restart the program