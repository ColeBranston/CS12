#Name: Cole Branston
#Date: 2022/11/07
#Purpose: Create a program that imitates a math sequence

n = 1 #initalizing the n variable for the later while loop

def mathSequence(n): #intitialzing the recursive function for calculating the nth term

    if n == 1: #checking if the term if term one
        return 2 #returning 2 which is the orignial number in the sequence

    else: #checking if the term isn't term 1
        return 3*mathSequence(n-1) - 1 #returning/calculating the nth term using the previous nth term
    
term = 2 #intializing the term var as 2 due to it being term 1

print("\nMath Sequence") #telling the user the title of the program
print("-------------") 

print("\nThe following sequence is defined as follows:\n\tt(1) = 2\n\tt(n) = 3 * t(n-1) - 1, n > 1") #Telling the user what the sequence is

print("\nThis program uses recursion to solve the problem") #telling the user that the program uses recursion to find the sequence

while True: #Infinite loop that runs as long as it doensn't get broken
    n = int(input("\nWhat term do you want to see? (0 to quit): ")) #asking the user what term they want to see

    while n < 0: #checking if the user input was below term 1
        print('\nPlease pick a term above or eqaul to 0') #telling the user to input the correct term
        n = int(input("\nWhat term do you want to see?: ")) #asking the user again what term they want to see

    if n == 0: #checking that the user doesn't want to quit
        break #breaking the loop

    term = mathSequence(n) #calling the recursive function

    print("\nt("+str(n)+") = ", term) #telling the user the nth term 
