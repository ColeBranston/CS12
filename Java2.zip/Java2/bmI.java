//Name: Cole Branston
//Date: 2022/12/25
//Purpose create a BMI calculator in java

import java.util.Scanner; //importing the scanner

public class bmI { //intializing the class
    public static void main(String[] args){ //initializing the code

        String again = "Y"; //initializing the again variable for later restart

        while (again.equals("Y")){ //while loop allowing for restart of the program

            Scanner scan = new Scanner(System.in); //initializing the scanner variable

            try { //try statement not allowing for the user to error out

                System.out.println("\nBMI Calculator"); //title of the program
                System.out.println("---------------");

                System.out.println("\nThis program calculates the bmi of a user based on their weight and height"); //telling the user the purpose of the program

                System.out.print("\nWhat is your weight (kg): "); //asking the user for their weight in kg
                double weight = scan.nextDouble();

                System.out.print("What is your height (m): "); //asking the user for their height in meters
                double height = scan.nextDouble();

                double bmi = (Math.round((weight/(height*height))*100))/100.0; //calculating the user's bmi

                System.out.println(); //making a space

                System.out.println("Your BMI is: "+bmi); //telling the user their bmi

                if (bmi < 15){ //checking if the bmi is less than 15
                    System.out.println("You are starving"); //telling the user they are starving

                }

                else if (bmi < 18.5){ //checking if the bmi is less than 18.5
                    System.out.println("You are underweight");//telling the user they are underweight

                }

                else if (bmi < 25){ //checking if the bmi is less than 25
                    System.out.println("You are ideal");//telling the user they are ideal

                }

                else if (bmi < 30){ //checking if the bmi is less than 30
                    System.out.println("You are overweight");//telling the user they are overweight

                }

                else if ( bmi <= 40){ //checking if the bmi is less than or equal to 40
                    System.out.println("You are obese");//telling the user they are obese

                }

                else { //checking if the bmi is greater than 40
                    System.out.println("You are morbidly obese");//telling the user they are morbidly obese

                }

                System.out.print("\nDo you want to restart the program (Y/N): "); //asking the user if they want to restart the program
                again = scan.next().toUpperCase();

            }

            catch (Exception e){ //catch statement not allowing for the user to error out
                System.out.println("\nAn error has occured"); //telling the user that 
                continue; //continuing the loop from where it left off

            }
        }
    }
}
