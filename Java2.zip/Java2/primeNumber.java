//Name: Cole Branston
//Date: 2022/12/25
//Purpose: create a program that tests if a number is prime or not

import java.util.Scanner; //importing scanner

public class primeNumber { //inializing the class

    public static void main(String[] args){ //initialzing code

        String again = "Y"; //inializing the again variable as Y

        while (again.equals("Y")) { //while loop used for restart of the program
            Scanner scan = new Scanner(System.in); //creating a scanner variable for user input

            try{ //try statement now allowing for a user to error out

                System.out.println("\nPrime Number Calculator"); //title of the program
                System.out.println("------------------------------");

                System.out.println("\nThis program calculates whether an imputted number is prime or not"); //telling the user the purpose of the program

                System.out.print("\nWhich number do you want to check if prime or not: "); //asking the user for their num
                int num = scan.nextInt();

                Boolean var = false; //setting the boolean variable to false

                for (int x = 2; x < Math.round(num/2)+1; x += 1){ //itterating through a range from 2 to half than the num by 1 each time
                    if (num % x == 0){ //checking if the num is prime (has a factor)
                        var = true; //setting the boolean variable to true
                        break; //breaking the loop
                    }
                }

                if (var == true){ //checking if the boolean variable is true
                    System.out.println("\nThis is not a prime number"); //telling the user that their number is not prime
                }

                else { //checking that the boolean variable is false
                    System.out.println("This is a prime number"); //telling the user that their number is a prime number
                }

                System.out.print("\nDo you want to restart the program? (Y/N): "); //asking the user if they want to retart the program
                again = scan.next().toUpperCase();
        
            }

            catch (Exception e){ //catch statement now allowing for the user to error out
                System.out.println("\nAn error has occured"); //telling the user that an error has occured
                continue; //continueing the program from where it left off

            }
        }
    }
}