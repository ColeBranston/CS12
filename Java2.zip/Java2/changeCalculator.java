//Name: Cole Branston
//Date: 2022/12/25
//Purpose: converts the change of the user

import java.util.Scanner; //importing the scanner to take user input

public class changeCalculator { //initializing the class
    public static void main(String[] args){ //initializing the code

        String again = "Y"; //initalizing the again varaiable as Y

        while (again.equals("Y")){ //while loop allowing for the user to restart the program
            Scanner scan = new Scanner(System.in); //initializing the scanner variable

            try { //try statement now allowing for the user to error out

                System.out.println("\nChange Converter"); //title of the program
                System.out.println("--------------------");

                System.out.println("This program calculates any amount of money into change of fives, toonies, loonies, quarters, dimes, nickels, and pennies"); //telling the user the purpose of the program

                System.out.print("\nHow many dollars ($) do you want to convert?: "); //asking the user for the money they want to convert in dollars ($)
                double num = scan.nextDouble();

                double change = num; //setting the change variable to the user input to be able to change later

                String stFives = ""; //initializing the display fives
                String stToonies = ""; //initializing the display toonies
                String stLoonies = ""; //initializing the display loonies
                String stQuarters = ""; //initializing the display quarters
                String stDimes = ""; //initializing the display dimes
                String stNickels = ""; //initializing the display nickels
                String stPennies = ""; //initializing the display pennies

                double fives = Math.round((change - (change % 5))/5.0); //getting how many fives are in the change variable (at this point its the initial user input)
                change -= fives*5; //decreasing the change variable by the amount of fives converted from the amount left

                double toonies = Math.round((change - (change % 2))/2.0); //getting how many toonies are in the change variable 
                change -= toonies*2; //decreasing the change variable by the amount of toonies converted from the amount left

                double loonies = Math.round((change - (change % 1))/1.0);  //getting how many loonies are in the change variable 
                change -= loonies*1; //decreasing the change variable by the amount of loonies converted from the amount left

                double quarters = Math.round((change - (change % 0.25))/0.25); //getting how many quarters are in the change variable 
                change -= quarters*0.25; //decreasing the change variable by the amount of quarters converted from the amount left

                double dimes = Math.round((change - (change % 0.10))/0.10); //getting how many dimes are in the change variable 
                change -= dimes*0.1; //decreasing the change variable by the amount of dimes converted from the amount left

                double nickels = Math.round((change - (change % 0.05))/0.05); //getting how many nickels are in the change variable 
                change -= nickels*0.05; //decreasing the change variable by the amount of nickels converted from the amount left

                double pennies = Math.round(change * 100); //taking what is left of the change and making it into pennies (has to be done this way or it bugs out)

                if (fives == 1){ //checking if there is one five
                    stFives = fives+" Five, "; //setting the display fives to the number of fives plus the gramatically correct ending

                }

                else if (fives > 1){ //checking that there are more than 1 five
                    stFives = fives+" Fives, "; //setting the display fives to the number of fives plus the gramatically correct ending

                }

                if (toonies == 1){ //checking if there is one toonie
                    stToonies = toonies+" Toonie, "; //setting the display toonies to the number of toonies plus the gramatically correct ending

                }

                else if (toonies > 1){ //checking that there are more than 1 toonie
                    stToonies = toonies+" Toonies, "; //setting the display toonies to the number of toonies plus the gramatically correct ending

                }

                if (loonies == 1){ //checking if there is one loonie
                    stLoonies = loonies+" Loonie, "; //setting the display loonies to the number of loonies plus the gramatically correct ending

                }

                else if (loonies > 1){ //checking that there are more than 1 loonie
                    stLoonies = loonies+" Loonies, "; //setting the display loonies to the number of loonies plus the gramatically correct ending

                }

                if (quarters == 1){ //checking if there is one quarter
                    stQuarters = quarters+" Quarter, "; //setting the display quarters to the number of quarters plus the gramatically correct ending

                }

                else if (quarters > 1){ //checking that there are more than 1 quarter
                    stQuarters = quarters+" Quarters, "; //setting the display quarters to the number of quarters plus the gramatically correct ending

                }

                if (dimes == 1){ //checking if there is one dime
                    stDimes = dimes+" Dime, "; //setting the display dimes to the number of dimes plus the gramatically correct ending

                }

                else if (dimes > 1){ //checking that there are more than 1 dime
                    stDimes = dimes+" Dimes, "; //setting the display dimes to the number of dimes plus the gramatically correct ending

                }

                if (nickels == 1){ //checking if there is one nickel
                    stNickels = nickels+" Nickel, "; //setting the display nickels to the number of nickels plus the gramatically correct ending

                }

                else if (nickels > 1){ //checking that there are more than 1 nickel
                    stNickels = nickels+" Nickels, "; //setting the display nickels to the number of nickels plus the gramatically correct ending

                }

                if (pennies == 1){ //checking if there is one pennie
                    stPennies = pennies+" Pennie"; //setting the display pennies to the number of pennies plus the gramatically correct ending

                }

                else if (pennies > 1){ //checking that there is more than 1 pennie
                    stPennies = pennies+" Pennies"; //setting the display pennies to the number of pennies plus the gramatically correct ending

                }

                System.out.println("\n$"+num+" requires: "+stFives+stToonies+stLoonies+stQuarters+stDimes+stNickels+stPennies); //telling the user what their money is in change.

                System.out.print("\nDo you want to restart the program? (Y/N): "); //asking the user if they want to restart the program
                again  = scan.next().toUpperCase();

            }

            catch (Exception e){ //catch statement not allowing for the user to error out
                System.out.println("\nAn error has occured"); //telling the user that an error has occured
                continue; //continueing the loop from where it left off
 
            }

        }
    }
}
