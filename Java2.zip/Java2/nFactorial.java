//Name: Cole Branston
//Date: 2022/12/25
//Purpose: create a program that out puts the factorial of any number inputed

import java.util.Scanner; //importing the user input scanner

public class nFactorial { //initalizing the class
    public static void main(String[] args){ //initalizing the code

        String again = "Y"; //initalizing the again variable as Y

        while (again.equals("Y")){ //loop allowing for restart

            Scanner scan = new Scanner(System.in); //intializing the scanner variable

            try{ //try statement not allowing for the user to error out

                System.out.println("\nnFactorial");//title of the program
                System.out.println("-------------");

                System.out.println("\nThis program calculates the factorial of any number\n\nEg. 4! = 4*3*2*1 "); //telling the user the purpose of the program

                System.out.print("\nWhat number do you want to see the factorial of: "); //asking the user for the number they want to factorial
                int num = scan.nextInt();

                int val = num; //setting the val variable to the user input (num)

                System.out.print("\n"+val+" * "); //starting the factorial

                for(int x = num-1; x > 1; x -= 1){ //for loop itterating from the num-1 to 1 by 1 each time
                    val *= x; //mulitplying the val variable by x each time
                    System.out.print(x+" * "); //telling the user what the factorial looks like
                }

                System.out.println("1 = "+val); //telling the user the factorial of their variable

                System.out.print("\nDo you want to restart the program? (Y/N): "); //asking the user if they want to restart the program
                again = scan.next().toUpperCase();

            }

            catch (Exception e){ //catch statement now allowing for erroring out
                System.out.println("\nAn error has occured"); //telling the user than an error has occured
                continue; //continuing the loop from where it left off

            }
        }
    }
}
