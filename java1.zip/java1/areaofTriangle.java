//Name: Cole Branston
//Date: 2022/12/12
//Purpose: Create a program that calculates the area of a triangle

import java.util.Scanner; //Importing the user input scanner

public class areaofTriangle{ //initializing the file
    public static void main(String[] args){ //intializing the code area 

        String again = "Y"; //initialzing the restart variable

        while (again.equals("Y")){ //while loop used for restart

            Scanner keyedInput = new Scanner(System.in); //Initialzing the scanner variable

            try{ //try statement now allowing for the user to error out

                System.out.println("\nArea of Triangle Calculator");
                System.out.println("----------------------------");

                System.out.println("\nThis program calculates the area of a trianlge based on its side lengths");

                System.out.print("\nWhat is the first side?: "); //asking the user for their first side
                double sideA = keyedInput.nextDouble();

                System.out.print("What is the second side?: "); //asking the user for their second side
                double sideB = keyedInput.nextDouble();

                System.out.print("What is the third side?: "); //asking the user for their third side
                double sideC = keyedInput.nextDouble(); 

                while ((sideA <= 0) || (sideB <= 0) || (sideC <= 0)){ //making sure the user used correct inputs for the triangle's side lengths

                    System.out.println("\nPlease use correct side lengths"); //telling the user to use correct side lengths

                    System.out.print("\nWhat is the first side?: "); //asking the user for their first side
                    sideA = keyedInput.nextDouble();

                    System.out.print("What is the second side?: "); //asking the user for their second side
                    sideB = keyedInput.nextDouble();

                    System.out.print("What is the third side?: "); //asking the user for their third side
                    sideC = keyedInput.nextDouble(); 

                }

                double s = (sideA + sideB + sideC)/2; //calculating the s variable

                double Area = Math.sqrt(s*(s-sideA)*(s-sideB)*(s-sideC)); //calculating the area of the user's triangle

                System.out.println("\nThe area of your triangle is: "+Math.round(Area*100)/100.0+" Units^2"); //telling the user the area of their triangle
               
                System.out.print("\nDo you want to restart the program? (Y/N): "); //asking the user if they want to restart the program
                again = keyedInput.next().toUpperCase();
            }

            catch (Exception e){ //catch statement not allowing for the user to error out

                System.out.println("\nAn error has occurred"); //telling the user that an error has occured
        
            }
        }
    }
}
