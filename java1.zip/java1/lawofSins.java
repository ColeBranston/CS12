//Name: Cole Branston
//Date: 2023/01/02 
//Purpose: Java program that calculates the other 2 sides and other angle of a triangle when the user inputs two angles and a length of a side oposite to one of the angles

import java.util.Scanner; //importing the scanner to take in input

public class lawofSins { //intialzing the file
    public static void main(String[] args){ //initalzing the code

        String again = "Y";

        while (again.equals("Y")) { //while true loop just to allow for the try and catch statements (infinite loop)

            Scanner keyedInput = new Scanner(System.in); //intiailzing the scanner variable

            try { //try statement not allowing for erroring out

                System.out.println("\nTriangle Angle and Side Lengths Calculator");
                System.out.println("-----------------------------------------------");

                System.out.println("This program calculates the b and c side lengths and the angle of the the oposing c side length");

                System.out.print("\nWhat is side A's length: "); //asking the user for the length of side a in their triangle
                double sideA = keyedInput.nextInt();

                System.out.print("What is angle A (Degrees): "); //asking the user for angle A in degrees
                double angleA = Math.toRadians(keyedInput.nextInt());

                System.out.print("What is angle B (Degrees): "); //asking the user for angle B in degrees
                double angleB = Math.toRadians(keyedInput.nextInt());

                while ((sideA <= 0) || (angleA <= 0) || (angleB <= 0)){ //making sure the user used correct inputs for the triangle's side lengths

                    System.out.println("\nUse the correct input"); //telling the user to use the correct input

                    System.out.print("\nWhat is side A's length: "); //asking the user for the length of side a in their triangle
                    sideA = keyedInput.nextInt();

                    System.out.print("What is angle A (Degrees): "); //asking the user for angle A in degrees
                    angleA = Math.toRadians(keyedInput.nextInt());

                    System.out.print("What is angle B (Degrees): "); //asking the user for angle B in degrees
                    angleB = Math.toRadians(keyedInput.nextInt());

                }
                double sideB = (sideA * Math.sin(angleB)) / Math.sin(angleA); //calculating sideB

                double angleC = Math.toRadians(180) - (angleA + angleB); //calculating angleC

                double sideC = (sideA * Math.sin(angleC)) / Math.sin(angleA); //calculating sideC

                System.out.println(); //making a space in the terminal

                System.out.println("Side B: "+(Math.round(sideB*100))/100.0); //telling the user the length of side B within their triangle

                System.out.println("Angle C: "+(Math.round(Math.toDegrees(angleC)*100))/100.0); //telling the user angle C in degrees within their triangle

            System.out.println("Side C: "+Math.round((sideC*100))/100.0); //telling the user the length of side C within their triangle


            System.out.print("\nDo you want to restart the program? (Y/N): ");
            again = keyedInput.next().toUpperCase();

            }

            catch (Exception e){ //catch statement that doesn't allow users to error out
                System.out.println("\nAn error has occured"); //telling the user that an error has occured
                continue;

            }
        }
    }
}
