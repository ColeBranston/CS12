class rifle: #intialzing the rifle class
    def __init__(self, barrel, stock): #contructor method
        self.barrel = barrel #defining the barrel
        self.stock = stock #defining the stock
        self.mag = 40 #defining the mag
        self.word = "Rifle"
        
        if barrel == "": #checking if the their is a barrel
            self.range = 60 #setting the range 

        else: #checking if their isn't a barrel
            self.range = 40 #setting the range

    def Fire(self): #definging the fire method

        if self.mag == 0: #checking if the mag is empty
            print("\nYou must reload") #telling the user to reload

        else: #checking that the mag isn't empty
            print("\nShooting Noises") #telling the user that the gun was shot
            self.mag -= 5 #decreasing the bullets in the mag
            print("\nMag Size: ", self.mag, "Bullets") #telling the user the number of bullets left in the bag

    def changeBarrel(self): #defining the change barrel method
        self.barrel = input("\nWhat new barrel do you want: ") #asking the user for their new barrel

        print("\nYour", self.word) #retelling the user their gun
        print("-----------") 

        print("\nBarrel :", self.barrel, "\nStock :", self.stock, "inches\nMag Size: ", self.mag, "Bullets\nRange: ", self.range, "ft") #telling the user their guns stats

    def Reload(self): #defining the reload method
        self.mag = 40 #resetting the mag
        print("\nMag Size: ", self.mag, "Bullets") #telling the user the number of bullets in their new mag

class SMG(rifle): #inializing the SMG class as an extension of the rifle class
    def __init__(self): #contructor method
        super().__init__(barrel, stock) #getting the original barrel and stock from the b

        self.firingSpeed = "10 bullets/second" #setting the firing speed
        self.range = 20 #setting the range
        self.mag = 60 #setting the mag size 
        self.word = "SMG" #setting the word
        
    def fastFire(self): #defining the fast fire method
        if self.mag <= 0: #checking if the mag is empty
            print("\nYou must reload") #telling the user that they must reload

        else: #checking that the mag isn't empty
            print("\nHigher Fire Rate Shooting Noises") #telling the user that the gun has been shot
            self.mag -= 20 #decreasing the number of bullets in the mag
            print("\nMag Size: ", self.mag, "Bullets") #telling the user the number of bullets left in the mag

    def Reload(self): #defining the reload method
        self.mag = 60 #reloading the mag
        print("\nMag Size: ", self.mag, "Bullets") #telling the user the reloaded mag

class Pistol(rifle): #intializing the pistol class as an extension of the rifle class
    def __init__(self, silencer): #contructor method
        super().__init__(barrel, stock) #getting the barrel and stock from the rifle class
 
        self.silencer = silencer #setting the silencer as the user inputted silencer

        if silencer == "": #checking if their is a silencer
            self.silencer = "None" #setting the silencer to none

        self.range = 20 #setting the range
        self.mag = 20 #setting the mag size
        self.word = "Pistol" #setting the word
        
    def Explode(self): #initializing the explode method
        print("\nExplosion") #telling the user that an explosion has taken place

    def Reload(self): #initialzing the reload method
        self.mag = 20 #reloading the mag
        print("\nMag Size: ", self.mag, "Bullets") #telling the user the number of bullets in the new mag

while True: #infinite loop

    try: #try statement that doesn't allow for the user to error out
            
        print("\nMarks Gun Customizer") #telling the user the title of the program
        print("---------------------")

        barrel = input("\nWhat barrel do you want: ") #asking the user for their barrel
        stock = eval(input("How large is your stock (inches): ")) #asking the user for the size of their stock

        yourRifle = rifle(barrel, stock) #calling the rifle class

        choice = int(input("\nWhich gun do you want to customize? (0. Quit 1. Rifle 2. SMG 3. Pistol): ")) #asking the user for the gun they want to see

        while choice < 0 or choice > 3: #checking that the user has inputted correct input 
            print("\nActually pick the correct number this time (1. Rifle 2. SMG 3. Pistol): ") #telling the user to pick the correct choice
            choice = int(input("Which gun do you want to customize? (1. Rifle 2. SMG 3. Pistol): ")) #asking the user for the gun they want to see

        while choice == 1: #checking that they choice to see the rifle (1)
 
            print("\nYour Rifle") #telling the user the gun they chose
            print("-----------")

            print("\nBarrel :", yourRifle.barrel, "\nStock :", yourRifle.stock, "inches\nMag Size: ", yourRifle.mag, "Bullets\nRange: ", yourRifle.range, "ft") #telling the user teh guns stats

            funcChoice = int(input("\nWhich function do you want to use (0. Quit 1. Fire 2. Change Barrel 3. Reload): ")) #asking the user if they want to use one of the guns functions

            while funcChoice != 0: #looping as long as the choice wasn't to quit

                if funcChoice == 1: #checking if the function choice was 1
                    yourRifle.Fire() #calling the fire method

                elif funcChoice == 2: #checking that the function choice was 2 
                    yourRifle.changeBarrel() #calling the change barrel method

                elif funcChoice == 3: #checking that the function choice is 3
                    yourRifle.Reload() #calling the reload function

                funcChoice = int(input("\nWhich function do you want to use (0. Quit 1. Fire 2. Change Barrel 3. Reload): ")) #asking the user if they want to use anymore functions

            break #breaking the loop

        while choice == 2: #checking that the choice was 2
            print("\nYour SMG") #telling the user their gun
            print("-----------")

            yourSMG = SMG() #calling the class

            print("\nBarrel :", yourSMG.barrel, "\nStock :", yourSMG.stock, "inches\nMag Size: ", yourSMG.mag, "Bullets\nRange: ", yourSMG.range, "ft") #telling the user the gun's stats

            funcChoice = int(input("\nWhich function do you want to use (0. Quit 1. Fire 2. Change Barrel, 3. Fast Fire 4. Reload): ")) #asking the user if they want to use any of the gun's functions

            while funcChoice != 0: #loop as long as the user doesn't want to quit

                if funcChoice == 1: #checking that the function choice is 1
                    yourSMG.Fire() #calling the fire function

                elif funcChoice == 2: #checking that the function choice is 2
                    yourSMG.changeBarrel() #calling the barrel change method

                elif funcChoice == 3: #checking that the function choice is 3 
                    yourSMG.fastFire() #calling the fast fire method

                elif funcChoice == 4: #checking that the function choice is 4
                    yourSMG.Reload() #calling the reload function

                funcChoice = int(input("\nWhich function do you want to use (0. Quit 1. Fire 2. Change Barrel, 3. Fast Fire 4. Reload): ")) #asking the user if they want to use any more functions

            break #breaking the loop

        while choice == 3: #checking that the gun choice is 3

            silencer = input("What silencer do you want (Leave blank if none): ") #asking the user for the silencer that they want for their pistol

            print("\nYour Pistol") #telling the user their gun they are viewing 
            print("-----------")

            yourPistol = Pistol(silencer) #calling the class

            print("\nBarrel :", yourPistol.barrel, "\nStock :", yourPistol.stock, "inches\nMag Size: ", yourPistol.mag, "Bullets\nRange: ", yourPistol.range, "ft\nSilencer: ", yourPistol.silencer) #telling the user the stats of their gun

            funcChoice = int(input("\nWhich function do you want to use (0. Quit 1. Fire 2. Change Barrel, 3. Explosion 4. Reload): ")) #asking the user if they want to use any of the gun's functions

            while funcChoice != 0: #looping as long as the user doesn't want to quit

                if funcChoice == 1: #checking that the function choice is 1
                    yourPistol.Fire() #calling the fire method

                elif funcChoice == 2: #checking that the function choice is 2
                    yourPistol.changeBarrel() #calling the change barrel method
 
                elif funcChoice == 3: #checking that the function choice is 3
                    yourPistol.Explode() #calling the explode method

                elif funcChoice == 4: #checking that the function choice is 4
                    yourPistol.Reload() #calling the reload function

                funcChoice = int(input("\nWhich function do you want to use (0. Quit 1. Fire 2. Change Barrel 3. Explosion 4. Reload): ")) #asking the user if they want to use any more functions of the gun

            break #breaking the loop

        again = input("\nDo you want to continue playing? (Y/N): ").upper() #asking the user if they want to restart the program

        while again != "Y" and again != "N": #checking for proper input
            print("\nAnswer the question properly") #telling the user to answer correctly
            again = input("Do you want to continue playing? (Y/N): ").upper() #reasking the user if they want to restart the program

        if again == "N": #checking if the again variable is N
            break #breaking the infinite loop

    except: #except statement not allowing for the user to error out
        print("\n---------------------") #telling the user that an error has occured
        print('An Error Has Occured')
        print("---------------------")

        continue #continueing from where the program left off