# Name: Cole Branston
# Date: 2022/09/15
# Purpose: Create a program that matches months to birthstones

#initializing again to be Y in order for later restart of the program
again = "Y"

#initializing the month lists and respective birtstone lists
monthList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "Novemeber", "December"]
modernList = ["Garnet", "Amethyst", "Aquamarine", "Diamond", "Emerald", "Pearl, Moonstone", "Ruby", "Peridot", "Sapphire", "Opal, Tourmarine", "Yellow Topaz, Citrine", "Blue Topaz, Turquoise"]
traditionalList = ["Garnet", "Amethyst", "Bloodstone", "Diamond", "Emerald", "Alexandrite", "Ruby", "Sardonyx", "Sapphire", "Tourmaline", "Citrine", "Zircon, Turquoise, Lapis Lazuli"]

#creating the function that contains the whole program
def monthstoneAssignment ():

    #telling the user the title of the program
    print("-----------")
    print("Birtstone")
    print("------------")

    print("Jewelry stores often sell birthday presents based on a person's birthstone.\nWhen a store clerk enters the number of the month, the correct birthstone is\nprinted.")

    #asking the user which month they were born and assigning it to a variable
    month = int(input("\nWhich month were you born? (1-12): "))

    #making the program look better
    print()

    #subtracting 1 from the month so that it works as a list index
    month -= 1

    #checking if the birthstones are the same 
    if modernList[month] != traditionalList[month]:

        #outputting the birthstones for there birth month and birthstone; modern birthstones and traditional birthstones
        print("Your month is", monthList[month], "\nYour Modern Birthstone is: ", modernList[month], "\nYour Traditional Birthstone is: ", traditionalList[month], "\n")

    #Checking if the birthstones are the same and carrying out specific instructions
    else:

        #Telling the user the birthstone for there month
        print("Your month is", monthList[month], "\nYour Modern Birthstone and Traditional Birthstone is: ", modernList[month])

    #making the program look better
    print()

#while loop allowing for restart by checking if the user wants to restart the program
while again == "Y":

    #try statement not allowing for erroring out
    try:
        #calling the function
        monthstoneAssignment()

        #asking the user if they want to restart the program
        again = input("Would you like to restart the program? (Y/N): ").upper()

    #except statement not allowing for erroring out
    except:

        #Telling the user than an error has occurred
        print("\nAn Error has occured, please try again")

        #continuing the program from where it left off
        continue

