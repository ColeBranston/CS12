#Name: Cole Branston
#Date: 2022/09/14
#Purpose: Be able to read a txt file and tell the user information about it.

#Initializing the list
numList = []

#opening the text file
numTXT = open("values.txt", "r")

#defining again as "Y"
again = "Y"

#reading the text file
numLine = numTXT.readline()

#checking if a line isn't blank, adding to the list, reading next line
while numLine != "":

    #stripping read lines of syntax
    numLineStripped =numLine.rstrip("\n")

    #adding stripped lines to a list
    numList.append(eval(numLineStripped))

    #reading the next line
    numLine = numTXT.readline()

#closing doc
numTXT.close()

#checking if the user wants to restart the program
while again == "Y":

    #Title of the program
    print("------------")
    print("Number Info")
    print("-------------")

    #Telling the user number of values in the text file
    print("There are", len(numList), "number in the text file")

    #sorting the list based from least to greatest
    numList.sort()

    #Telling the user the smallest value in the text file
    print("The smallest number in the text file is: ", numList[0])

    #Telling the user the largest valie in the text file
    print("The largest number in the text file is: ", numList[len(numList)-1])

    #Telling the user the average of the values in the text files
    print("The average of the values in the text file is: ",round(sum(numList)/len(numList),2))

    #Telling the user the median valus in the text file
    print("The median value in the list is: ", numList[len(numList)//2])

    #asking the user if they want to restart the program
    again = input("\nDo you want to restart the program? (Y/N): ").upper()

    #making the program look better
    print()