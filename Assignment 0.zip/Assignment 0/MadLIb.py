# Name: Cole Branston
# Date: 2022/09/14
# Purpose: Program that creates a MadLib

#importing random
import random

#initializing the function
def createLists():
    pluralList = []
    verbsList= []
    singularnounsList = []

    #opening the text file
    pluralTXT = open("Plurals.txt", "r")

    #reading the text file
    pluralLine = pluralTXT.readline()

    #checking if a line isn't blank, adding to the list, reading next line
    while pluralLine != "":

        #stripping read lines of syntax
        plurallineStripped = pluralLine.rstrip("\n")    #adding stripped lines to a list
        pluralList.append(plurallineStripped)

        #reading the next line
        pluralLine = pluralTXT.readline()

    #closing doc
    pluralTXT.close()

    #opening the text file
    verbsTXT = open("Verbs.txt", "r")

    #reading the text file
    verbsLine = verbsTXT.readline()

    #checking if a line isn't blank, adding to the list, reading next line
    while verbsLine != "":

        #stripping read lines of syntax
        verbslineStripped =verbsLine.rstrip("\n")    #adding stripped lines to a list
        verbsList.append(verbslineStripped)

        #reading the next line
        verbsLine = verbsTXT.readline()

    #closing doc
    verbsTXT.close()

    #opening the text file
    singularnounsTXT = open("Singulars.txt", "r")

    #reading the text file
    singularnounsLine = singularnounsTXT.readline()

    #checking if a line isn't blank, adding to the list, reading next line
    while singularnounsLine != "":

        #stripping read lines of syntax
        singularnounsStripped =singularnounsLine.rstrip("\n")    #adding stripped lines to a list
        singularnounsList.append(singularnounsStripped)

        #reading the next line
        singularnounsLine = singularnounsTXT.readline()

    #closing doc
    singularnounsTXT.close()

    #outputting the title to tell the user what the program is
    print("-------")
    print("MadLib")
    print("-------")

    #telling the user teh purpose of this program
    print("This program randomly picks one word from each \nlist plural nouns, verbs, singular nouns and creates \npotentially comical sentence.")

    #randomly choosing each word
    pluralWord = random.choice(pluralList)
    verbWord = random.choice(verbsList)
    singualrnounWord = random.choice(singularnounsList)

    #printing the user's madllib
    print("\n"+str(pluralWord), verbWord, singualrnounWord)

#defining again as "Y"
again = "Y"

#checking if the user wants to restart the program
while again == "Y":

    #try statement now allowing for erroring out
    try:

        #calling the function createLists()
        createLists()

        #asking the user if they want to restart the program
        again = input("\nDo you want to restart the program? (Y/N): ").upper()

    #except statement now allowing for erroring out
    except:

        #continuing the program from where it left off
        continue
