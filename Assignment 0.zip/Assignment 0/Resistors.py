# Name: Cole Branston
# Date: 2022/09/15
# Purpose: Takes in colours of resistors and outputs the resistance

#initiailizing the dictionary
colours = {"BLACK": 0, "ORANGE": 3, "BROWN": 1, "BLUE":6, "WHITE": 9, "YELLOW":4, "VIOLET":7, "RED":2 , "GREEN":5, "GREY":7}

#defining the again statement to restart the program
again = "Y"

#while loop to repeat the program 
while again == "Y": 

    #try statement that doesn't allow for erroring out
    try:

        #printing the title of the program
        print("\n----------------------")
        print("Resistance Calculators")
        print("----------------------")

        #asking the user for colours of there resistor
        colourInput = input(("\nWhat is the colour of your resistor: ")).upper()

        #splitting the user input into a list
        colourinputList = colourInput.split("-")

        #defining the first half of the equation
        value1 = str(colours[colourinputList[0]])+str(colours[colourinputList[1]])

        #calculating the total resistance
        finalValue = int(value1) ** colours[colourinputList[2]]

        #outputting the final statement of the restistor and its resistance
        print("\nThe total resistance for the resistor", colourInput, "is: ", finalValue, "Ohms" )

        #asking the user if they want to restart the program
        again = input("\nDo you want to restart the program? (Y/N): ").upper()

    #except statement that catches any errors
    except: 

        #telling the user that an error has occured
        print("\nAn error has occured, please try again")

        #continuing the program after the error
        continue