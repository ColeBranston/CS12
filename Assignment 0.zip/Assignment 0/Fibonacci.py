# Name: Cole Branston
# Date: 2022/09/19
# Purpose: create a program that asks the user the term of a fibonacci series up to the 50th term.

#initializing again as Y in order to later restart the program
again = "Y"

#initializing the function which creates the fibonacci series list using the previous terms in the list 
def fibonacciCreation():

    #for loop that runs through number 1 - 50
    for x in range(1, 49):

        #gets the sum of the previous terms and creates the new term 
        sum = series[x]+series[x-1]

        #adds the new sum to the end of the list
        series.append(sum)

#checking if again is Y in order to restart the program
while again == "Y":

    #try statement not allowing for erroring out
    try:

        #initializing the fibonacci list 
        series = [1, 1]

        #defining the ending of the term that will be later outputted
        ending = "th"


        #calling function 
        fibonacciCreation()

        #telling the user the title of the program
        print("\n-----------------")
        print("Fibonacci Series")
        print("-----------------")

        #telling the user the purpose of the program
        print("\nThe Fibonacci series is a sequence of numbers in which each number\nin the sequence equals the sum to the two preceding numbers.\nThe first two numbers in the sequence are 1.\nThe sequence of numbers are 1,1,2,3,5,8,13,21,...")

        #asking the user for the term they wish to see
        term = input("\nWhat term would you like to see? (1-50): ")

        #checking if the term the user inputted is 0
        while int(term) == 0:

            #asking the user to input a new a term because there is no 0th term
            term = input("\nThere is no 0th term, please input a new one (1-50): ")

        #splitting the input in in order to change the endings later on
        termList = term.split()

        #checkng if the ending number in the list is 1 
        if int(termList[-1]) == 1:

            #setting the ending to st 
            ending = "st"

        #checking if the last number in the list is 2 
        elif int(termList[-1]) == 2:

            #setting the ending to nd
            ending = "nd"

        
        #checking if the ending number in the list is 3
        elif int(termList[-1]) == 3:

            #setting the ending to rd
            ending = "rd"

        #printing the final statement telling the user the term they wished to see and that term in the fibonacci series
        print("\nThe", str(term)+str(ending), "term in the series is: "+str(series[int(term)-1]))

        again = input("\nDo you want to restart the program? (Y/N): ").upper()

    #except statement now allowing for erroring out
    except: 

        #telling the user that an error has occured and to try again
        print("\n---------------------------------------")
        print("An error has occured, please try again")
        print("----------------------------------------")

        #continuing the program where it left off
        continue

