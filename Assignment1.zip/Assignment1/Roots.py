# Name: Cole Branston
# Date: 09/22/2022
# Purpose: This program finds the real roots

#importing my function
import Functions as f

#initializng again as Y so that I can later restart the program
again = "Y"

#checking if again is Y in order to restart the program
while again == "Y":

    #try statement that doesn't allow for erroring out
    try:

        #printing the title of the program
        print("\n-----------------")
        print("Roots Calculator")
        print("-----------------")

        #telling the user the purpose of the program
        print("\nThis program will take in coefficients of a quadratic and output it's roots")

        #asking the user for for there a, b, and c values
        a = eval(input("Input your a coeffificent: "))

        b = eval(input("Input your b coeffificent: "))

        c = eval(input("Input your c coeffificent: "))

        #calling the function
        xint = f.findRoots(a,c,b)

        #checking if the function returns true
        if f.findRoots(a,c,b):

            #checking the x ints are the same
            if xint[0] == xint[1]:

                #printing the final statement
                print("\nThere is 1 real root: \n\nX1 =", xint[0])

            #checking if the x ints aren't the same
            else:

                #telling the user that there are two roots
                print("\nThere are two real roots: \n\nX1 = ", xint[0], "\nX2 = ", xint[1])

        #checking if the function returned false
        else:

            #telling the user that there were no roots in there quadratic
            print("\nThere are no real roots")

        #asking the user if they want to restart the program
        again = input("\nDo you want to restart the program? (Y/N): ").upper()

    #except statement not allowing for erroring out
    except:

        #telling the user that an error has occured
        print("\nAn error has occurred, please try again")

        #continueing the program from where the user left off
        continue