# Name: Cole Branston
# Date: 2022/09/28
# Purpose: Create a program that tells the user the smallest prime factor

#importing my functions
import Functions as f

#importing the math libary
import math

#intiializing again for the later restart of the program
again = "Y"

#while loop that checks if again equals yes and repeats for restart
while again == "Y":

    #try statement now allowing for restart
    try: 

        #telling the user the title of the program
        print("\n------------------")
        print("Smallest Factor")
        print("------------------")

        #telling the user the purpose of the program
        print("\nThis program will take in a number and find the smallest prime factor")

        #asking the user the number they want to find the smallest prime factor for
        Number = abs(int(input("\nWhat is your number?: ")))

        #calling the function
        x = f.factor(Number)

        #telling the user the smallest prime factor of the number
        print("\nThe smallest prime factor is: ", x)

        #asking the user if they want to restart the program
        again = input("\nDo you want to restart the program? (Y/N): ").upper()

    #exept statement now allowing erroring out
    except:

        #telling the user that an error has occurred
        print("\nAn error has occurred, please try again")

        #continueing the program from where it left off
        continue

