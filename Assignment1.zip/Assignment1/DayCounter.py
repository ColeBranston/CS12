# Name: Cole Branston
# Date: 2022/09/28
# Purpose: Create a program that asks the user for a day, month, and year and outputs how many days from the start of that year that time is

#importing the function
import Functions as f

#initializng again as Y for later restart of the program
again = "Y"

#checking if again is Y so that the program can run/rerun
while again == "Y": 

    #try statement now allowing for erroring out
    try: 
        
        #telling the user the title of the program
        print("\n------------")
        print("Day Counter")
        print("-------------")

        #Telling the user the purpose of the program
        print("\nThis program will count the number of days from the\nbeginning of a year for any day, month, and year")

        #asking the user for there day, month, and year
        Day = int(input("\nEnter your day: "))
        Month = int(input("Enter your month: "))
        Year = int(input("Enter your year: "))

        #calling the variable from the function
        totalDays = f.DayNumber(Year, Month, Day)

        #telling the user the amount of days that have passed since the start of there year
        print("\nThe number of days from the beginning of the year is: ", totalDays)

        #asking the user if they want to restart the program
        again = input("Do you want to restart the program? (Y/N): ").upper()

    #except statement now allowing for erroring out
    except:
    
        #telling the user that an error has occured
        print("An error has occurred, please try again")

        #continueing the program from where it left off
        continue