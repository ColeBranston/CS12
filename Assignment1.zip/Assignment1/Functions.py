
#imports the math library
import math

#initializing a function that takes a quadratics coefficients and outputs it's roots
def findRoots(a, c, b):

    #defining the discriminant
    dis = b**2-4*(a)*(c)
    
    #checking if the discrimant is greater than or equal to 0
    if dis >= 0:

        #calculating the first intercept
        x1 = round((-b+math.sqrt(dis))/(2*a),2)

        #calculating the second intercept
        x2 = round((-b-math.sqrt(dis))/(2*a),2)

        #returning True and the two intercepts
        return True and x1, x2    

    #checking if the value is below 0
    else:

        #returning false
        return False

#initializing the function that takes in a users number and outputs and smallest prime factor
def factor(Number):

    #itterating through a range from 2 to the number
    for x in range (2, Number+1):

        #checking if the number in the range is a factor of the user's number
        if Number % x == 0:

            #itterating through a range from 2 to that factor
            for i in range(2, x+1):

                #checking if the factor is composite
                if x % i == 0:

                    #breaking the loop if the factor is composite
                    break

            #returning the smallest prime factor
            return x

#initializing the function that that takes in the year, month, and day in order to determine the amount of time in days that has passed since the start of that year
def DayNumber(Year, Month, Day):

    #checking if the year is a leap year and if it is divisable by 100 or 400
    if Year % 4 == 0 and Year % 100 != 0 or Year % 400 == 0:

        #initialing the leap year dictionary
        monthDict = {1:31,2:29,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31}

    #checking if it isn't a leap year
    else:

        #initialing the normal year dictionary
        monthDict = {1:31,2:28,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31}

    #checking that the user didn't put in a false value
    while monthDict[Month] < Day:

        #telling the user to input a correct value for days
        print("\nInput a correct number of days")

        #asking how many days once again
        Day = int(input("\nEnter your day: "))
    
    #initializng month sum for later addition
    monthSum = 0

    #for loop that interates through the range between 1, and the user month-1
    for x in range(1, Month):

        #adding the sum of days for the months
        monthSum += monthDict[x]

    #calculating the total days that have passed
    totalDays = monthSum + Day

    #returning the total days that have passed since the start of the year
    return totalDays
